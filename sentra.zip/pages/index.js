import Sentra from '../components/Sentra';

export default function Home() {
  return <Sentra />;
}